import{_ as m}from"./Iframe.vuevuetypestyleindex0lang-B7JEvM-U.js";import"./vendor-CMgWRFUC.js";export{m as default};

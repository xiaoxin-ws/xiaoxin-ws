import{_ as m}from"./Iframe.vue_vue_type_style_index_0_lang-B7JEvM-U.js";import"./vendor-CMgWRFUC.js";export{m as default};

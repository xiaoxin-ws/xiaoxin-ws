import{_ as m}from"./Iframe.vuevuetypestyleindex0lang-DiVIRjl3.js";import"./@vue-B-Waonw5.js";export{m as default};

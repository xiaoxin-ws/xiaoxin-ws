const r=(o,s)=>{const c=o.__vccOpts||o;for(const[t,n]of s)c[t]=n;return c};export{r as _};

import{_ as m}from"./Iframe.vue_vue_type_style_index_0_lang-DoQZWrf2.js";import"./vendor-aDZpGBEG.js";export{m as default};
